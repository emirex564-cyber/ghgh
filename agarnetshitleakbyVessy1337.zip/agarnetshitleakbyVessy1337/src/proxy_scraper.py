#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AgarNet C2 - Multi-Source Automated Proxy Scraper
Scrapes fresh SOCKS4, SOCKS5, and HTTP proxies concurrently from verified public repositories.
"""

import os
import re
import time
import threading
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed

PROXY_REGEX = re.compile(r'\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?):(?:[0-9]{2,5})\b')

SOCKS4_SOURCES = [
    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=10000&country=all",
    "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks4.txt",
    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt",
    "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks4.txt",
    "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS4_RAW.txt",
    "https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks4.txt",
    "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks4.txt",
    "https://raw.githubusercontent.com/zevtyardt/proxy-list/main/socks4.txt",
]

SOCKS5_SOURCES = [
    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=10000&country=all",
    "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt",
    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt",
    "https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt",
    "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks5.txt",
    "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt",
    "https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks5.txt",
    "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks5.txt",
    "https://raw.githubusercontent.com/zevtyardt/proxy-list/main/socks5.txt",
]

HTTP_SOURCES = [
    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all",
    "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt",
    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
    "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
    "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
    "https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
    "https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt",
]

HEADERS = {
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}

def fetch_url(url, timeout=10):
    """Fetch proxy list from a single URL."""
    found = set()
    try:
        resp = requests.get(url, headers=HEADERS, timeout=timeout)
        if resp.status_code == 200:
            matches = PROXY_REGEX.findall(resp.text)
            for m in matches:
                found.add(m)
    except Exception:
        pass
    return found

def scrape_category(sources, max_workers=8):
    """Concurrently scrape a list of sources."""
    collected = set()
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(fetch_url, src) for src in sources]
        for f in as_completed(futures):
            try:
                res = f.result()
                collected.update(res)
            except Exception:
                pass
    return sorted(list(collected))

def get_payload_dir():
    """Resolve the Payload directory path."""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    payload_dir = os.path.join(current_dir, "Payload")
    if not os.path.exists(payload_dir):
        # Alternative when running from root
        payload_dir = os.path.join(os.getcwd(), "src", "Payload")
    os.makedirs(payload_dir, exist_ok=True)
    return payload_dir

def scrape_all():
    """Scrape SOCKS4, SOCKS5, and HTTP proxies and save them to files."""
    payload_dir = get_payload_dir()

    socks4 = scrape_category(SOCKS4_SOURCES)
    socks5 = scrape_category(SOCKS5_SOURCES)
    http = scrape_category(HTTP_SOURCES)

    all_proxies = sorted(list(set(socks4 + socks5 + http)))

    # Write socks4 (primary for bot)
    s4_file = os.path.join(payload_dir, "socks4.txt")
    if socks4:
        with open(s4_file, "w", encoding="utf-8") as f:
            f.write("\n".join(socks4) + "\n")

    # Write socks5
    s5_file = os.path.join(payload_dir, "socks5.txt")
    if socks5:
        with open(s5_file, "w", encoding="utf-8") as f:
            f.write("\n".join(socks5) + "\n")

    # Write http
    http_file = os.path.join(payload_dir, "http.txt")
    if http:
        with open(http_file, "w", encoding="utf-8") as f:
            f.write("\n".join(http) + "\n")

    # Unified list
    all_file = os.path.join(payload_dir, "all_proxies.txt")
    if all_proxies:
        with open(all_file, "w", encoding="utf-8") as f:
            f.write("\n".join(all_proxies) + "\n")

    stats = {
        "socks4": len(socks4),
        "socks5": len(socks5),
        "http": len(http),
        "total": len(all_proxies),
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    return stats

_auto_scraper_thread = None
_latest_stats = {}

def get_latest_stats():
    global _latest_stats
    return _latest_stats

def _scraper_loop(interval_minutes=30):
    global _latest_stats
    while True:
        try:
            _latest_stats = scrape_all()
        except Exception:
            pass
        time.sleep(interval_minutes * 60)

def start_auto_scraper(interval_minutes=30):
    """Start background auto scraper thread."""
    global _auto_scraper_thread
    if _auto_scraper_thread is None or not _auto_scraper_thread.is_alive():
        _auto_scraper_thread = threading.Thread(
            target=_scraper_loop,
            args=(interval_minutes,),
            daemon=True
        )
        _auto_scraper_thread.start()

if __name__ == "__main__":
    print("[*] Starting multi-source proxy scraper...")
    result = scrape_all()
    print(f"[+] SOCKS4  : {result['socks4']}")
    print(f"[+] SOCKS5  : {result['socks5']}")
    print(f"[+] HTTP    : {result['http']}")
    print(f"[+] Total   : {result['total']}")
    print(f"[+] Updated at: {result['timestamp']}")
